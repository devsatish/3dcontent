var APP_DATA = {
  "scenes": [
    {
      "id": "0-airplane---cam-1",
      "name": "AIRPLANE - cam 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -3.0096291509097135,
        "pitch": 0.24394753037990213,
        "fov": 1.3264749465418482
      },
      "linkHotspots": [
        {
          "yaw": 2.4047934106678532,
          "pitch": 0.17452203631900076,
          "rotation": 0,
          "target": "1-airplane---cam-4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-airplane---cam-4",
      "name": "AIRPLANE - cam 4",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "qtvr",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
